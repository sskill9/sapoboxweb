// ツール固有の初期化（ダミー）
document.addEventListener('DOMContentLoaded', () => {
  console.log('Excel/CSV Viewer sample loaded.');
});
