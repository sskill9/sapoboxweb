// ==================================================
// content.js — CONTENTブロック（ツール本体＋TOPへ戻るボタン）
// ==================================================
(function () {
  "use strict";

  // ===== 初期取得ブロック =====
  var contentEl = document.getElementById("content-block");
  if (!contentEl) return;
  // ===== 初期取得ブロックここまで =====


  // ==================================================
  // ===== UI描画ブロック =====
  // ==================================================
  contentEl.innerHTML = `
  <section class="container py-4" aria-label="暗号化／復号化ツール本体">

    <!-- ツール情報バー（左：バッジ／右：説明文） -->
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-3">

      <!-- 左側：バッジ類（暗号化／汎用ツール） -->
      <div class="mb-2 mb-md-0">
        <span class="badge rounded-pill fw-semibold me-2"
              style="background-color:#0d6efd;color:#ffffff;font-size:0.78rem;">
          暗号化
        </span>
        <span class="badge rounded-pill fw-semibold"
              style="background-color:#20c997;color:#ffffff;font-size:0.78rem;">
          汎用ツール
        </span>
      </div>

      <!-- 右側：概要説明 -->
      <div class="small text-muted">
        ※ サーバーへ送信しません（ブラウザ内で処理します）
      </div>

    </div>

    <!-- 2カラム（md以上で左右=暗号化／復号化、スマホは縦1カラム） -->
    <div class="row gy-4 gx-4">
      <div class="col-12 col-md-6">

        <!-- ===== 暗号化カードブロック ===== -->
        <div class="card shadow-sm">
          <div class="card-header bg-light">
            <strong>【送信側】ファイルを暗号化</strong>
          </div>
          <div class="card-body">

            <div class="row g-3">

              <!-- ドロップゾーン（T005寄せ） -->
              <div class="col-12">
                <div id="encryptDropZone"
                     class="border rounded-3 text-center"
                     style="border:2px dashed rgba(13,110,253,.45); background: rgba(13,110,253,.03); padding: 28px; cursor: pointer;"
                     aria-label="暗号化するファイルのドラッグ＆ドロップ領域">
                  <div style="font-size: 40px; line-height: 1;">📁</div>
                  <div class="fw-bold mt-2">ここにファイルをドラッグ＆ドロップ</div>
                  <div class="text-muted small">（クリックでも選択できます）</div>
                  <div id="encryptDropFileName" class="small text-muted mt-2"></div>
                </div>
              </div>

              <!-- 「または」 -->
              <div class="col-12">
                <div class="text-muted small">
                  または、こちらのボタンからファイルを選択
                </div>
              </div>

              <!-- ファイル選択（従来IDを維持） -->
              <div class="col-12">
                <label class="form-label" for="encryptFileInput">暗号化するファイル</label>
                <input class="form-control" type="file" id="encryptFileInput">
              </div>

              <!-- パスワード入力 + ボタン（同じ行で下端を揃える） -->
              <div class="col-12">
                <div class="row g-3 align-items-end">
                  <div class="col-12 col-md-6">
                    <label class="form-label" for="encryptPasswordInput">パスワード</label>

                    <!-- 目アイコン（👁‍🗨）で表示切替：input-group -->
                    <div class="input-group">
                      <input class="form-control" type="password" id="encryptPasswordInput">
                      <button class="btn btn-outline-secondary"
                              type="button"
                              id="encryptPasswordToggle"
                              aria-label="パスワードを表示">
                        👁‍🗨
                      </button>
                    </div>
                    <!-- 目アイコンここまで -->

                  </div>

                  <div class="col-12 col-md-6 d-grid">
                    <button type="button" class="btn btn-primary" id="encryptButton">
                      暗号化してダウンロード（.angou）
                    </button>
                  </div>
                </div>
              </div>

              <!-- 注釈 -->
              <div class="col-12 col-md-6">
                <div class="form-text">
                  ※ できるだけ長いパスワードを推奨します。
                </div>
              </div>

              <div class="col-12">
                <div id="encryptStatus" class="small text-muted"></div>
              </div>
            </div>

          </div>
        </div>
        <!-- ===== 暗号化カードブロックここまで ===== -->

      </div>

      <div class="col-12 col-md-6">

        <!-- ===== 復号化カードブロック ===== -->
        <div class="card shadow-sm">
          <div class="card-header bg-light">
            <strong>【受信側】ファイルを復号化</strong>
          </div>
          <div class="card-body">

            <div class="row g-3">

              <!-- ドロップゾーン（T005寄せ） -->
              <div class="col-12">
                <div id="decryptDropZone"
                     class="border rounded-3 text-center"
                     style="border:2px dashed rgba(25,135,84,.45); background: rgba(25,135,84,.03); padding: 28px; cursor: pointer;"
                     aria-label="復号化するファイルのドラッグ＆ドロップ領域">
                  <div style="font-size: 40px; line-height: 1;">📁</div>
                  <div class="fw-bold mt-2">ここに .angou ファイルをドラッグ＆ドロップ</div>
                  <div class="text-muted small">（クリックでも選択できます）</div>
                  <div id="decryptDropFileName" class="small text-muted mt-2"></div>
                </div>
              </div>

              <!-- 「または」 -->
              <div class="col-12">
                <div class="text-muted small">
                  または、こちらのボタンからファイルを選択
                </div>
              </div>

              <!-- ファイル選択（従来IDを維持） -->
              <div class="col-12">
                <label class="form-label" for="decryptFileInput">暗号化されたファイル（.angou）</label>
                <input class="form-control" type="file" id="decryptFileInput">
              </div>

              <!-- パスワード入力 + ボタン（同じ行で下端を揃える） -->
              <div class="col-12">
                <div class="row g-3 align-items-end">
                  <div class="col-12 col-md-6">
                    <label class="form-label" for="decryptPasswordInput">パスワード</label>

                    <!-- 目アイコン（👁‍🗨）で表示切替：input-group -->
                    <div class="input-group">
                      <input class="form-control" type="password" id="decryptPasswordInput">
                      <button class="btn btn-outline-secondary"
                              type="button"
                              id="decryptPasswordToggle"
                              aria-label="パスワードを表示">
                        👁‍🗨
                      </button>
                    </div>
                    <!-- 目アイコンここまで -->

                  </div>

                  <div class="col-12 col-md-6 d-grid">
                    <button type="button" class="btn btn-success" id="decryptButton">
                      復号化してダウンロード
                    </button>
                  </div>
                </div>
              </div>

              <!-- 注釈 -->
              <div class="col-12 col-md-6">
                <div class="form-text">
                  ※ パスワードを忘れると復号できません。
                </div>
              </div>

              <div class="col-12">
                <div id="decryptStatus" class="small text-muted"></div>
              </div>
            </div>

          </div>
        </div>
        <!-- ===== 復号化カードブロックここまで ===== -->

      </div>
    </div>

  </section>

  <button id="backToTopBtn"
          type="button"
          class="btn btn-primary position-fixed bottom-0 end-0 m-3 shadow"
          style="display:none; z-index: 1080;">
    ↑
  </button>
  `;
  // ==================================================
  // ===== UI描画ブロックここまで =====
  // ==================================================


  // ==================================================
  // ===== UIイベント・状態変数ブロック =====
  // ==================================================
  if (window.__T006_ANGOU_UI_BOUND__) return;
  window.__T006_ANGOU_UI_BOUND__ = true;

  var encryptFileInput = document.getElementById("encryptFileInput");
  var decryptFileInput = document.getElementById("decryptFileInput");
  var encryptDropZone = document.getElementById("encryptDropZone");
  var decryptDropZone = document.getElementById("decryptDropZone");

  var encryptDropFileName = document.getElementById("encryptDropFileName");
  var decryptDropFileName = document.getElementById("decryptDropFileName");

  var encryptPasswordInput = document.getElementById("encryptPasswordInput");
  var decryptPasswordInput = document.getElementById("decryptPasswordInput");

  var encryptPasswordToggle = document.getElementById("encryptPasswordToggle");
  var decryptPasswordToggle = document.getElementById("decryptPasswordToggle");

  var encryptButton = document.getElementById("encryptButton");
  var decryptButton = document.getElementById("decryptButton");

  var encryptStatus = document.getElementById("encryptStatus");
  var decryptStatus = document.getElementById("decryptStatus");

  var selectedEncryptFile = null;
  var selectedDecryptFile = null;
  // ==================================================
  // ===== UIイベント・状態変数ブロックここまで =====
  // ==================================================


  // ==================================================
  // ===== 共通ユーティリティブロック =====
  // ==================================================
  function setStatus(el, msg) {
    if (!el) return;
    el.textContent = msg || "";
  }

  function setDropFileName(el, file) {
    if (!el) return;
    if (!file) {
      el.textContent = "";
      return;
    }
    el.textContent = "選択中： " + file.name;
  }

  function readFileAsArrayBuffer(file) {
    return new Promise(function (resolve, reject) {
      if (!file) {
        reject(new Error("ファイルが選択されていません。"));
        return;
      }
      if (file.arrayBuffer) {
        file.arrayBuffer().then(resolve).catch(reject);
        return;
      }
      var reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = function () { reject(reader.error || new Error("ファイル読み込みに失敗しました。")); };
      reader.readAsArrayBuffer(file);
    });
  }

  function applyHighlight(dropZone, on, kind) {
    if (!dropZone) return;
    if (on) {
      dropZone.style.background = (kind === "encrypt")
        ? "rgba(13,110,253,.08)"
        : "rgba(25,135,84,.08)";
      dropZone.style.borderColor = (kind === "encrypt")
        ? "rgba(13,110,253,.85)"
        : "rgba(25,135,84,.85)";
    } else {
      dropZone.style.background = (kind === "encrypt")
        ? "rgba(13,110,253,.03)"
        : "rgba(25,135,84,.03)";
      dropZone.style.borderColor = (kind === "encrypt")
        ? "rgba(13,110,253,.45)"
        : "rgba(25,135,84,.45)";
    }
  }

  function setInputFile(fileInput, file) {
    if (!fileInput || !file) return;
    try {
      var dt = new DataTransfer();
      dt.items.add(file);
      fileInput.files = dt.files;
    } catch (e) {
      // DataTransfer が使えない環境では input 側へ反映できない場合があります
      // ただし本ツールは selectedXxxFile を優先するため動作は継続可能
    }
  }
  // ==================================================
  // ===== 共通ユーティリティブロックここまで =====
  // ==================================================


  // ==================================================
  // ===== パスワード表示切替ブロック =====
  // ==================================================
  function setupPasswordToggle(inputEl, toggleBtn) {
    if (!inputEl || !toggleBtn) return;

    toggleBtn.addEventListener("click", function () {
      var currentType = String(inputEl.getAttribute("type") || "");
      if (currentType.toLowerCase() === "password") {
        inputEl.setAttribute("type", "text");
        toggleBtn.textContent = "🙈";
        toggleBtn.setAttribute("aria-label", "パスワードを非表示");
      } else {
        inputEl.setAttribute("type", "password");
        toggleBtn.textContent = "👁‍🗨";
        toggleBtn.setAttribute("aria-label", "パスワードを表示");
      }
    });
  }

  setupPasswordToggle(encryptPasswordInput, encryptPasswordToggle);
  setupPasswordToggle(decryptPasswordInput, decryptPasswordToggle);
  // ==================================================
  // ===== パスワード表示切替ブロックここまで =====
  // ==================================================


  // ==================================================
  // ===== ドラッグ＆ドロップ設定ブロック =====
  // ==================================================
  function setupDropZone(dropZone, fileInput, dropFileNameEl, kind) {
    if (!dropZone) return;

    function setSelectedFile(file) {
      if (kind === "encrypt") {
        selectedEncryptFile = file;
        if (file) {
          setStatus(encryptStatus, "");
          setDropFileName(dropFileNameEl, file);
        } else {
          setDropFileName(dropFileNameEl, null);
        }
      } else {
        selectedDecryptFile = file;
        if (file) {
          setStatus(decryptStatus, "");
          setDropFileName(dropFileNameEl, file);
        } else {
          setDropFileName(dropFileNameEl, null);
        }
      }
    }

    // クリックでファイル選択
    dropZone.addEventListener("click", function () {
      if (fileInput) fileInput.click();
    });

    // drag系
    ["dragenter", "dragover"].forEach(function (evtName) {
      dropZone.addEventListener(evtName, function (event) {
        event.preventDefault();
        event.stopPropagation();
        applyHighlight(dropZone, true, kind);
      });
    });

    ["dragleave", "drop"].forEach(function (evtName) {
      dropZone.addEventListener(evtName, function (event) {
        event.preventDefault();
        event.stopPropagation();
        applyHighlight(dropZone, false, kind);
      });
    });

    dropZone.addEventListener("drop", function (event) {
      var dt = event.dataTransfer;
      if (!dt || !dt.files || dt.files.length === 0) return;

      var file = dt.files[0];
      if (!file) return;

      // inputにも反映（可能な環境ではUIも揃う）
      setInputFile(fileInput, file);
      // selectedにも反映（こちらが本命）
      setSelectedFile(file);
    });

    // input[type=file] の選択
    if (fileInput) {
      fileInput.addEventListener("change", function (event) {
        var files = event.target.files;
        var file = (files && files.length) ? files[0] : null;
        if (file) {
          setSelectedFile(file);
        }
      });
    }
  }

  setupDropZone(encryptDropZone, encryptFileInput, encryptDropFileName, "encrypt");
  setupDropZone(decryptDropZone, decryptFileInput, decryptDropFileName, "decrypt");
  // ==================================================
  // ===== ドラッグ＆ドロップ設定ブロックここまで =====
  // ==================================================


  // ==================================================
  // ===== 暗号化処理ブロック =====
  // ==================================================
  async function handleEncrypt() {
    try {
      setStatus(encryptStatus, "");

      var file = selectedEncryptFile || (encryptFileInput && encryptFileInput.files && encryptFileInput.files[0]);
      var password = encryptPasswordInput ? String(encryptPasswordInput.value || "") : "";

      if (!file) {
        setStatus(encryptStatus, "暗号化するファイルを選択してください。");
        return;
      }
      if (!password) {
        setStatus(encryptStatus, "パスワードを入力してください。");
        return;
      }
      if (typeof window.angouEncryptArrayBuffer !== "function") {
        setStatus(encryptStatus, "暗号化関数が見つかりません。tool.js の読み込み順を確認してください。");
        return;
      }

      setStatus(encryptStatus, "暗号化中…（ファイルサイズにより時間がかかる場合があります）");

      var buffer = await readFileAsArrayBuffer(file);
      var encryptedBuffer = await window.angouEncryptArrayBuffer(buffer, password);

      var blob = new Blob([encryptedBuffer], { type: "application/octet-stream" });

      var outName = (typeof window.angouMakeEncryptedFilename === "function")
        ? window.angouMakeEncryptedFilename(file.name)
        : (String(file.name || "file") + ".angou");

      if (typeof window.angouDownloadBlob === "function") {
        window.angouDownloadBlob(blob, outName);
      } else {
        var url = URL.createObjectURL(blob);
        var a = document.createElement("a");
        a.href = url;
        a.download = outName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }

      setStatus(encryptStatus, "完了： " + outName + " をダウンロードしました。");
    } catch (e) {
      console.error(e);
      var msg = (e && e.message) ? String(e.message) : String(e);
      setStatus(encryptStatus, "エラー： " + msg);
    }
  }
  // ==================================================
  // ===== 暗号化処理ブロックここまで =====
  // ==================================================


  // ==================================================
  // ===== 復号化処理ブロック =====
  // ==================================================
  async function handleDecrypt() {
    try {
      setStatus(decryptStatus, "");

      var file = selectedDecryptFile || (decryptFileInput && decryptFileInput.files && decryptFileInput.files[0]);
      var password = decryptPasswordInput ? String(decryptPasswordInput.value || "") : "";

      if (!file) {
        setStatus(decryptStatus, "復号化する .angou ファイルを選択してください。");
        return;
      }
      if (!password) {
        setStatus(decryptStatus, "パスワードを入力してください。");
        return;
      }
      if (typeof window.angouDecryptArrayBuffer !== "function") {
        setStatus(decryptStatus, "復号化関数が見つかりません。tool.js の読み込み順を確認してください。");
        return;
      }

      setStatus(decryptStatus, "復号化中…（ファイルサイズにより時間がかかる場合があります）");

      var buffer = await readFileAsArrayBuffer(file);
      var decryptedBuffer = await window.angouDecryptArrayBuffer(buffer, password);

      var blob = new Blob([decryptedBuffer], { type: "application/octet-stream" });

      var outName = (typeof window.angouMakeDecryptedFilename === "function")
        ? window.angouMakeDecryptedFilename(file.name)
        : String(file.name || "file.angou").replace(/\.angou$/i, "");

      if (typeof window.angouDownloadBlob === "function") {
        window.angouDownloadBlob(blob, outName);
      } else {
        var url = URL.createObjectURL(blob);
        var a = document.createElement("a");
        a.href = url;
        a.download = outName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }

      setStatus(decryptStatus, "完了： " + outName + " をダウンロードしました。");

    // ===== 復号化エラーメッセージ整形ブロック =====
    } catch (e) {
      console.error(e);

      var msg = (e && e.message) ? String(e.message) : String(e);

      // WebCrypto の復号失敗（典型：パスワード違い）はブラウザ実装によって OperationError になりがち
      if (
        msg === "OperationError" ||
        msg.indexOf("OperationError") !== -1 ||
        msg.indexOf("The operation failed") !== -1 ||
        msg.indexOf("tag") !== -1 ||
        msg.indexOf("authenticate") !== -1 ||
        msg.indexOf("integrity") !== -1
      ) {
        setStatus(decryptStatus, "暗号化時のパスワードと異なります");
        return;
      }

      setStatus(decryptStatus, "エラー： " + msg);
    }
    // ===== 復号化エラーメッセージ整形ブロックここまで =====
  }
  // ==================================================
  // ===== 復号化処理ブロックここまで =====
  // ==================================================


  // ==================================================
  // ===== ボタンイベント紐付けブロック =====
  // ==================================================
  if (encryptButton) {
    encryptButton.addEventListener("click", function () {
      handleEncrypt();
    });
  }

  if (decryptButton) {
    decryptButton.addEventListener("click", function () {
      handleDecrypt();
    });
  }
  // ==================================================
  // ===== ボタンイベント紐付けブロックここまで =====
  // ==================================================


  // ==================================================
  // ===== TOPへ戻るボタン制御ブロック =====
  // ==================================================
  var backBtn = document.getElementById("backToTopBtn");
  if (backBtn) {
    window.addEventListener("scroll", function () {
      if (window.pageYOffset > 200) {
        backBtn.style.display = "inline-flex";
      } else {
        backBtn.style.display = "none";
      }
    });

    backBtn.addEventListener("click", function () {
      var topEl = document.getElementById("page-top");
      if (topEl && topEl.scrollIntoView) {
        topEl.scrollIntoView({ behavior: "smooth" });
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    });
  }
  // ==================================================
  // ===== TOPへ戻るボタン制御ブロックここまで =====
  // ==================================================

})();
