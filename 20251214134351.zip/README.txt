# サポ箱 スターターパック（4層レイアウト）
- /components/topbar.html と /components/footer.html はサイト上でのみ読み込まれます。
- /tools/excel-viewer/ はツール単体でも開けます（dual-loader が共通→ローカルを自動切替）。
- まずは /index.html をブラウザで開いて、トップバー／フッターが表示されることを確認してください。
