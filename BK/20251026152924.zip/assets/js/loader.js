(function(){
  // バージョン（キャッシュバスター）
  var v = '20251021';

  function loadCSS(href){ var l=document.createElement('link'); l.rel='stylesheet'; l.href=href; document.head.appendChild(l); }
  function loadJS(src, cb){ var s=document.createElement('script'); s.defer=true; s.src=src; s.onload=function(){cb&&cb();}; document.head.appendChild(s); }

  // まずはCDNのBootstrap。失敗しても最低限のベースCSSで見栄えを担保。
  loadCSS('https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css');
  loadCSS('/assets/css/base.css?v='+v);
  loadCSS('/assets/css/tools.css?v='+v);

  loadJS('https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js');
})();