// ①と④の差し込み（サイト上でのみ存在）
(async function(){
  async function inject(sel, url){
    const el = document.querySelector(sel);
    if(!el) return;
    try{
      const r = await fetch(url, {cache:'no-store'});
      if(r.ok){ el.innerHTML = await r.text(); }
      else { el.style.display='none'; }
    }catch(e){
      el.style.display='none'; // 単体DL時など /components 不在の場合
    }
  }
  await inject('#global-topbar','/components/topbar.html');
  await inject('#global-footer','/components/footer.html');
})();