# Overview
The benchmarks folder contains benchmark examples.  These examples will perform recognition (or some operation) on pre-set example images, in order to assess speed or accuracy.  These are intended to provide a more robust way to assess potential changes to Tesseract.js compared to unit tests, which are written to run quickly and have binary pass/fail conditions. 

