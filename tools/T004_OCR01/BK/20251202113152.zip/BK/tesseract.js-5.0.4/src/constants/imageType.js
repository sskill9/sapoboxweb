module.exports = {
  COLOR: 0,
  GREY: 1,
  BINARY: 2,
};
