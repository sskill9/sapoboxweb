// content.js — CONTENTブロック（ツール本体＋TOPへ戻るボタン）
//
// 【このファイルで主に書き換えるポイント】
//  1) バッジ部分の文言（テンプレ／コンタクトセンター向け など）
//  2) 右側の概要説明テキスト
//  3) 入力エリア／結果エリアの見出し・ラベル・サンプルUI
//  4) 必要に応じて、カード構成（2カラム→1カラムなど）を各ツール用に調整
//
//  ※ ツール名は TOP バー（top.js）側に一本化済み。
//  ※ TOPへ戻るボタン（#backToTopBtn）の挙動は共通機能なので、基本そのまま使用。

(function () {
  var contentEl = document.getElementById("content-block");
  if (!contentEl) return;

  contentEl.innerHTML = `
<div class="container py-4">

  <!-- ツール情報バー（左：バッジ／右：説明文） -->
  <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-3">

    <!-- 左側：バッジ類（丸ピル統一版） -->
    <div class="mb-2 mb-md-0" id="scAppBadges">
      <span class="badge rounded-pill fw-semibold"
            style="background-color:#20c997;color:#ffffff;font-size:0.78rem;">
        ショートカット
      </span>
    </div>

    <!-- 右側：概要説明 -->
    <div class="text-muted small" id="scAppDesc">
      キーワード検索（例：コピー／スクリーンショット）と、画面上のキー選択でショートカットを絞り込めます。
      ※このプロトタイプは Windows11 / Excel（仮データ：JS読込）です。
    </div>

  </div>

  <!-- 入力／結果エリア -->
  <section class="mb-5">
    <div class="row gy-4">

      <!-- 入力エリア -->
      <div class="col-lg-6">
        <div class="card shadow-sm h-100">

          <div class="card-header bg-primary-subtle fw-bold">
            検索・フィルタ
          </div>

          <div class="card-body">

            <div class="mb-3">
              <label for="scKeyword" class="form-label fw-semibold">キーワード検索</label>
              <input
                type="text"
                id="scKeyword"
                class="form-control"
                placeholder="例：コピー / クリップボード / スクリーンショット / エクスプローラー / 設定 / ロック / フィルター">
              <div class="form-text">
                ショートカット名・説明・キー表記（例：Win+Shift+S）から検索します。
              </div>
            </div>

            <div class="mb-3">
              <div class="d-flex align-items-center justify-content-between gap-2">
                <div class="fw-semibold">アプリフィルタ：</div>
                <button type="button" class="btn btn-outline-secondary btn-sm" id="scClearAppsBtn">
                  アプリ選択をクリア
                </button>
              </div>

              <div class="mt-2" id="scAppFilter" class="d-flex flex-wrap gap-2"></div>

              <div class="form-text">
                複数選択OK（未選択＝全アプリ表示）。例：Excel だけに絞り込む、Win11+Excel のみ表示、など。
              </div>
            </div>

            <div class="mb-3">
              <div class="d-flex flex-wrap align-items-center gap-2">
                <div class="fw-semibold">選択中のキー：</div>
                <div id="scSelectedKeys" class="d-flex flex-wrap gap-1"></div>
              </div>
              <div class="mt-2 d-flex flex-wrap gap-2">
                <button type="button" class="btn btn-outline-secondary btn-sm" id="scClearKeysBtn">
                  キー選択をクリア
                </button>
                <button type="button" class="btn btn-outline-secondary btn-sm" id="scClearAllBtn">
                  すべてクリア
                </button>

                <div class="form-check ms-auto">
                  <input class="form-check-input" type="checkbox" value="" id="scExactMatch">
                  <label class="form-check-label" for="scExactMatch">
                    キー完全一致
                  </label>
                </div>
              </div>
            </div>

            <hr>

            <div class="mb-2 fw-semibold">ソフトウェアキーボード（クリックで選択）</div>
            <div class="text-muted small mb-2">
              選択したキーを「含む」ショートカットを表示します（「キー完全一致」をONで完全一致に切替）。
            </div>

            <div id="scKeyboard" class="d-flex flex-column gap-2"></div>

          </div>
        </div>
      </div>

      <!-- 結果エリア -->
      <div class="col-lg-6">
        <div class="card shadow-sm h-100">

          <div class="card-header bg-primary-subtle fw-bold d-flex align-items-center justify-content-between">
            <span>検索結果</span>
            <span class="text-muted small" id="scResultStat">-</span>
          </div>

          <div class="card-body">
            <div class="alert alert-info py-2 small mb-3">
              <div class="fw-semibold">使い方の例</div>
              <ul class="mb-0">
                <li>「コピー」と検索 → Win11 / Excel のコピー系が出ます</li>
                <li>Win と Shift と S を選択 → 画面切り取り（Win+Shift+S）が出ます</li>
                <li>アプリフィルタで「Excel」だけ選択 → Excel のみ表示になります</li>
              </ul>
            </div>

            <div id="scResults"></div>
          </div>

        </div>
      </div>

    </div>
  </section>

</div>

<!-- 右下：TOPへ戻るボタン -->
<button id="backToTopBtn"
        type="button"
        class="btn btn-primary btn-sm rounded-circle shadow"
        aria-label="ページの先頭へ戻る">
  ↑
</button>
`;

  // =========================
  // ショートカットデータ（data/*.js を結合）
  // =========================
  function buildShortcutDataFromDatasets() {
    var datasets = (window.SC_SHORTCUT_DATASETS || []);
    var merged = [];

    for (var i = 0; i < datasets.length; i++) {
      var ds = datasets[i] || {};
      var appLabel = ds.appLabel || ds.appId || "UnknownApp";
      var list = ds.shortcuts || [];

      for (var j = 0; j < list.length; j++) {
        var s = list[j] || {};
        merged.push({
          app: appLabel,
          type: s.type || "chord",
          keys: s.keys || [],
          name: s.name || "",
          desc: (s.desc != null ? s.desc : (s.description != null ? s.description : ""))
        });
      }
    }

    return merged;
  }

  var SHORTCUT_DATA = buildShortcutDataFromDatasets();

  // =========================
  // アプリ表示名（短縮表記）
  // =========================
  var APP_DISPLAY_ALIAS = {
    "Windows11": "Win11"
  };

  function appLabelToDisplay(appLabel) {
    if (APP_DISPLAY_ALIAS[appLabel]) return APP_DISPLAY_ALIAS[appLabel];
    return appLabel;
  }

  function getUniqueAppsFromData() {
    var map = Object.create(null);
    var out = [];

    for (var i = 0; i < SHORTCUT_DATA.length; i++) {
      var a = SHORTCUT_DATA[i].app;
      if (!a) continue;
      if (!map[a]) {
        map[a] = true;
        out.push(a);
      }
    }

    // 安定ソート（表示名の昇順）
    out.sort(function (a, b) {
      var da = appLabelToDisplay(a);
      var db = appLabelToDisplay(b);
      if (da < db) return -1;
      if (da > db) return 1;
      return 0;
    });

    return out;
  }

  var APP_LIST = getUniqueAppsFromData();

  // バッジ（アプリ名）を自動表示
  (function renderAppBadges() {
    var badgesEl = document.getElementById("scAppBadges");
    if (!badgesEl) return;

    var html = "";
    for (var k = 0; k < APP_LIST.length; k++) {
      var raw = APP_LIST[k];
      var disp = appLabelToDisplay(raw);

      html += `
        <span class="badge rounded-pill fw-semibold me-2"
              style="background-color:#0d6efd;color:#ffffff;font-size:0.78rem;">
          ${escapeHtml(disp)}
        </span>
      `;
    }

    html += `
      <span class="badge rounded-pill fw-semibold"
            style="background-color:#20c997;color:#ffffff;font-size:0.78rem;">
        ショートカット
      </span>
    `;

    badgesEl.innerHTML = html;

    var descEl = document.getElementById("scAppDesc");
    if (descEl) {
      var appsText = (APP_LIST.length > 0)
        ? APP_LIST.map(function (a) { return appLabelToDisplay(a); }).join(" / ")
        : "（データ未読込）";

      descEl.textContent = "キーワード検索（例：コピー／スクリーンショット）と、画面上のキー選択でショートカットを絞り込めます。※このプロトタイプは " + appsText + "（仮データ：JS読込）です。";
    }
  })();

  // =========================
  // キー表記の正規化
  // =========================
  var KEY_ALIAS = {
    "Windows": "Win",
    "WIN": "Win",
    "Control": "Ctrl",
    "CTRL": "Ctrl",
    "Alternate": "Alt",
    "ALT": "Alt",
    "Shift": "Shift",
    "SHIFT": "Shift",
    "Enter": "Enter",
    "RETURN": "Enter",
    "Esc": "Esc",
    "Escape": "Esc",
    "Backspace": "Backspace",
    "Del": "Delete",
    "Delete": "Delete",
    "PrintScreen": "PrtScn",
    "PrtSc": "PrtScn",
    "PrtScn": "PrtScn",
    "ArrowLeft": "Left",
    "ArrowRight": "Right",
    "ArrowUp": "Up",
    "ArrowDown": "Down",
    ".": "."
  };

  function normalizeKey(k) {
    if (k == null) return "";
    var s = String(k).trim();
    if (KEY_ALIAS[s]) return KEY_ALIAS[s];
    return s;
  }

  function comboToString(keys) {
    return (keys || []).map(function (k) { return normalizeKey(k); }).join("+");
  }

  function uniqueArray(arr) {
    var map = Object.create(null);
    var out = [];
    for (var i = 0; i < arr.length; i++) {
      var k = arr[i];
      if (!map[k]) {
        map[k] = true;
        out.push(k);
      }
    }
    return out;
  }

  function arrayContains(arr, v) {
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] === v) return true;
    }
    return false;
  }

  function removeFromArray(arr, v) {
    var out = [];
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] !== v) out.push(arr[i]);
    }
    return out;
  }

  // =========================
  // UI構築：状態
  // =========================
  var selectedKeys = [];
  var selectedApps = []; // 未選択＝全アプリ

  var keywordInput = document.getElementById("scKeyword");
  var selectedKeysEl = document.getElementById("scSelectedKeys");
  var keyboardEl = document.getElementById("scKeyboard");
  var resultEl = document.getElementById("scResults");
  var resultStatEl = document.getElementById("scResultStat");
  var clearKeysBtn = document.getElementById("scClearKeysBtn");
  var clearAllBtn = document.getElementById("scClearAllBtn");
  var exactMatchChk = document.getElementById("scExactMatch");

  var appFilterEl = document.getElementById("scAppFilter");
  var clearAppsBtn = document.getElementById("scClearAppsBtn");

  function isSelectedKey(k) {
    var nk = normalizeKey(k);
    for (var i = 0; i < selectedKeys.length; i++) {
      if (selectedKeys[i] === nk) return true;
    }
    return false;
  }

  function toggleKey(k) {
    var nk = normalizeKey(k);
    var next = [];
    var found = false;
    for (var i = 0; i < selectedKeys.length; i++) {
      if (selectedKeys[i] === nk) {
        found = true;
      } else {
        next.push(selectedKeys[i]);
      }
    }
    if (!found) next.push(nk);
    selectedKeys = uniqueArray(next);
    renderSelectedKeys();
    renderKeyboard();
    renderResults();
  }

  function clearKeys() {
    selectedKeys = [];
    renderSelectedKeys();
    renderKeyboard();
    renderResults();
  }

  function clearApps() {
    selectedApps = [];
    renderAppFilter();
    renderResults();
  }

  function clearAll() {
    if (keywordInput) keywordInput.value = "";
    if (exactMatchChk) exactMatchChk.checked = false;
    clearKeys();
    clearApps();
  }

  function toggleApp(appRaw) {
    if (!appRaw) return;

    if (selectedApps.length === 0) {
      // 全表示状態から、まず1つだけ選ぶ
      selectedApps = [appRaw];
    } else {
      if (arrayContains(selectedApps, appRaw)) {
        selectedApps = removeFromArray(selectedApps, appRaw);
      } else {
        selectedApps = selectedApps.concat([appRaw]);
      }
      selectedApps = uniqueArray(selectedApps);
    }

    renderAppFilter();
    renderResults();
  }

  function renderSelectedKeys() {
    if (!selectedKeysEl) return;

    if (selectedKeys.length === 0) {
      selectedKeysEl.innerHTML = `<span class="text-muted small">なし</span>`;
      return;
    }

    var html = "";
    for (var i = 0; i < selectedKeys.length; i++) {
      var k = selectedKeys[i];
      html += `<span class="badge text-bg-primary">${escapeHtml(k)}</span>`;
    }
    selectedKeysEl.innerHTML = html;
  }

  function renderAppFilter() {
    if (!appFilterEl) return;

    if (APP_LIST.length === 0) {
      appFilterEl.innerHTML = `<span class="text-muted small">（アプリデータなし）</span>`;
      return;
    }

    // 選択なし＝全選択の見た目にする
    var allMode = (selectedApps.length === 0);

    var html = "";

    // 「全アプリ」ボタン
    html += `
      <button type="button"
              class="${allMode ? "btn btn-primary btn-sm" : "btn btn-outline-secondary btn-sm"}"
              id="scAppAllBtn"
              aria-pressed="${allMode ? "true" : "false"}">
        全アプリ
      </button>
    `;

    for (var i = 0; i < APP_LIST.length; i++) {
      var raw = APP_LIST[i];
      var disp = appLabelToDisplay(raw);
      var active = allMode ? true : arrayContains(selectedApps, raw);

      html += `
        <button type="button"
                class="${active ? "btn btn-primary btn-sm" : "btn btn-outline-secondary btn-sm"} sc-app-btn"
                data-app="${escapeAttr(raw)}"
                aria-pressed="${active ? "true" : "false"}">
          ${escapeHtml(disp)}
        </button>
      `;
    }

    appFilterEl.innerHTML = html;

    var allBtn = document.getElementById("scAppAllBtn");
    if (allBtn) {
      allBtn.addEventListener("click", function () {
        // 全アプリに戻す（未選択状態にする）
        selectedApps = [];
        renderAppFilter();
        renderResults();
      });
    }

    var btns = appFilterEl.querySelectorAll(".sc-app-btn");
    for (var b = 0; b < btns.length; b++) {
      btns[b].addEventListener("click", function (ev) {
        var app = ev.currentTarget.getAttribute("data-app");
        toggleApp(app);
      });
    }
  }

  function createKeyBtn(label, value) {
    var k = normalizeKey(value || label);
    var active = isSelectedKey(k);
    var cls = active ? "btn btn-primary btn-sm" : "btn btn-outline-secondary btn-sm";
    return `<button type="button" class="${cls} sc-key-btn" data-key="${escapeAttr(k)}" aria-pressed="${active ? "true" : "false"}">${escapeHtml(label)}</button>`;
  }

  function renderKeyboard() {
    if (!keyboardEl) return;

    var rows = [];

    // Row: modifiers
    rows.push([
      createKeyBtn("Win", "Win"),
      createKeyBtn("Ctrl", "Ctrl"),
      createKeyBtn("Alt", "Alt"),
      createKeyBtn("Shift", "Shift")
    ]);

    // Row: navigation / specials
    rows.push([
      createKeyBtn("Esc", "Esc"),
      createKeyBtn("Tab", "Tab"),
      createKeyBtn("Enter", "Enter"),
      createKeyBtn("Space", "Space"),
      createKeyBtn("Backspace", "Backspace"),
      createKeyBtn("Delete", "Delete"),
      createKeyBtn("PrtScn", "PrtScn")
    ]);

    // Row: arrows
    rows.push([
      createKeyBtn("←", "Left"),
      createKeyBtn("↑", "Up"),
      createKeyBtn("↓", "Down"),
      createKeyBtn("→", "Right")
    ]);

    // Row: function keys
    var fRow = [];
    for (var fi = 1; fi <= 12; fi++) {
      fRow.push(createKeyBtn("F" + fi, "F" + fi));
    }
    rows.push(fRow);

    // Row: digits
    var dRow = [];
    for (var di = 0; di <= 9; di++) {
      dRow.push(createKeyBtn(String(di), String(di)));
    }
    rows.push(dRow);

    // Row: letters A-Z
    var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var rowA = [];
    for (var li = 0; li < letters.length; li++) {
      rowA.push(createKeyBtn(letters[li], letters[li]));
    }
    rows.push(rowA);

    var html = "";
    for (var ri = 0; ri < rows.length; ri++) {
      html += `<div class="d-flex flex-wrap gap-2">${rows[ri].join("")}</div>`;
    }
    keyboardEl.innerHTML = html;

    // bind
    var btns = keyboardEl.querySelectorAll(".sc-key-btn");
    for (var bi = 0; bi < btns.length; bi++) {
      btns[bi].addEventListener("click", function (ev) {
        var key = ev.currentTarget.getAttribute("data-key");
        toggleKey(key);
      });
    }
  }

  // =========================
  // 結果レンダリング
  // =========================
  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function escapeAttr(s) {
    return escapeHtml(s).replace(/`/g, "&#96;");
  }

  function includesAllKeys(haveKeys, needKeys) {
    for (var i = 0; i < needKeys.length; i++) {
      var nk = normalizeKey(needKeys[i]);
      var ok = false;
      for (var j = 0; j < haveKeys.length; j++) {
        if (normalizeKey(haveKeys[j]) === nk) {
          ok = true;
          break;
        }
      }
      if (!ok) return false;
    }
    return true;
  }

  function sameKeySet(a, b) {
    if (a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) {
      var ai = normalizeKey(a[i]);
      var found = false;
      for (var j = 0; j < b.length; j++) {
        if (normalizeKey(b[j]) === ai) {
          found = true;
          break;
        }
      }
      if (!found) return false;
    }
    return true;
  }

  function scoreItem(item, q, selected, exact) {
    var text = [
      item.app,
      item.name,
      item.desc,
      comboToString(item.keys)
    ].join(" ").toLowerCase();

    var score = 0;

    if (q) {
      if (text.indexOf(q) >= 0) score += 50;
      if (comboToString(item.keys).toLowerCase().indexOf(q) >= 0) score += 30;
      if (item.name.toLowerCase().indexOf(q) >= 0) score += 40;
      if (item.desc.toLowerCase().indexOf(q) >= 0) score += 20;
    } else {
      score += 10;
    }

    if (selected.length > 0) {
      if (exact) {
        if (sameKeySet(item.keys, selected)) score += 200;
        else score -= 200;
      } else {
        if (includesAllKeys(item.keys, selected)) score += 120;
        else score -= 120;
      }
    }

    return score;
  }

  function isAppMatched(itemApp) {
    if (selectedApps.length === 0) return true; // 全アプリ
    return arrayContains(selectedApps, itemApp);
  }

  function renderResults() {
    if (!resultEl) return;

    var q = "";
    if (keywordInput && keywordInput.value) q = String(keywordInput.value).trim().toLowerCase();

    var exact = !!(exactMatchChk && exactMatchChk.checked);

    var filtered = [];
    for (var i = 0; i < SHORTCUT_DATA.length; i++) {
      var it = SHORTCUT_DATA[i];

      // アプリ条件
      if (!isAppMatched(it.app)) continue;

      // キー条件
      if (selectedKeys.length > 0) {
        if (exact) {
          if (!sameKeySet(it.keys, selectedKeys)) continue;
        } else {
          if (!includesAllKeys(it.keys, selectedKeys)) continue;
        }
      }

      // キーワード条件
      if (q) {
        var hay = (it.app + " " + it.name + " " + it.desc + " " + comboToString(it.keys)).toLowerCase();
        if (hay.indexOf(q) < 0) continue;
      }

      filtered.push(it);
    }

    // ソート（スコア降順）
    filtered.sort(function (a, b) {
      var sa = scoreItem(a, q, selectedKeys, exact);
      var sb = scoreItem(b, q, selectedKeys, exact);
      if (sb !== sa) return sb - sa;

      // 同点ならキー文字列→名前で安定化
      var ca = comboToString(a.keys);
      var cb = comboToString(b.keys);
      if (ca < cb) return -1;
      if (ca > cb) return 1;
      if (a.name < b.name) return -1;
      if (a.name > b.name) return 1;
      return 0;
    });

    // 表示
    if (resultStatEl) {
      resultStatEl.textContent = filtered.length + " 件";
    }

    if (filtered.length === 0) {
      resultEl.innerHTML = `
        <div class="text-muted">
          該当するショートカットがありません。<br>
          キーワードを変えるか、キー／アプリの選択をクリアしてみてください。
        </div>
      `;
      return;
    }

    var html = `<ul class="list-group">`;
    for (var r = 0; r < filtered.length; r++) {
      var item = filtered[r];
      var combo = comboToString(item.keys);
      var appDisp = appLabelToDisplay(item.app);

      html += `
        <li class="list-group-item">
          <div class="d-flex align-items-start justify-content-between gap-2">
            <div class="me-2">
              <div class="fw-bold">${escapeHtml(combo)}</div>
              <div class="mt-1">
                <span class="badge text-bg-secondary me-2">${escapeHtml(appDisp)}</span>
                <span class="fw-semibold">${escapeHtml(item.name)}</span>
              </div>
              <div class="text-muted small mt-1">${escapeHtml(item.desc)}</div>
            </div>
            <div class="d-flex flex-column gap-2">
              <button type="button" class="btn btn-outline-primary btn-sm sc-copy-btn" data-copy="${escapeAttr(combo)}">
                コピー
              </button>
            </div>
          </div>
        </li>
      `;
    }
    html += `</ul>`;
    resultEl.innerHTML = html;

    // copy bind
    var copyBtns = resultEl.querySelectorAll(".sc-copy-btn");
    for (var ci = 0; ci < copyBtns.length; ci++) {
      copyBtns[ci].addEventListener("click", function (ev) {
        var txt = ev.currentTarget.getAttribute("data-copy") || "";
        copyText(txt);
      });
    }
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(function () {
        fallbackCopy(text);
      });
    } else {
      fallbackCopy(text);
    }
  }

  function fallbackCopy(text) {
    try {
      var ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    } catch (e) {
      // 何もしない（環境により不可）
    }
  }

  // =========================
  // イベント
  // =========================
  if (keywordInput) {
    keywordInput.addEventListener("input", function () {
      renderResults();
    });
  }

  if (exactMatchChk) {
    exactMatchChk.addEventListener("change", function () {
      renderResults();
    });
  }

  if (clearKeysBtn) {
    clearKeysBtn.addEventListener("click", function () {
      clearKeys();
    });
  }

  if (clearAppsBtn) {
    clearAppsBtn.addEventListener("click", function () {
      clearApps();
    });
  }

  if (clearAllBtn) {
    clearAllBtn.addEventListener("click", function () {
      clearAll();
    });
  }

  // 初期描画
  renderSelectedKeys();
  renderAppFilter();
  renderKeyboard();
  renderResults();

  // TOPへ戻るボタンの制御
  var backBtn = document.getElementById("backToTopBtn");
  if (!backBtn) return;

  window.addEventListener("scroll", function () {
    if (window.pageYOffset > 200) {
      backBtn.style.display = "inline-flex";
    } else {
      backBtn.style.display = "none";
    }
  });

  backBtn.addEventListener("click", function () {
    var topEl = document.getElementById("page-top");
    if (topEl && topEl.scrollIntoView) {
      topEl.scrollIntoView({ behavior: "smooth" });
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  });
})();
