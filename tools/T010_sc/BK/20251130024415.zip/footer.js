// footer.js — Support Tool Box 共通フッター（TOPバーと同じ高さ・navbar準拠）
(function () {
  var footerEl = document.getElementById("footer-block");
  if (!footerEl) return;

  footerEl.innerHTML = `
<footer class="navbar navbar-expand-md navbar-dark bg-primary mt-auto">
  <div class="container d-flex flex-column flex-md-row align-items-center justify-content-between">

    <!-- 左側：サイト名 -->
    <div class="navbar-text mb-2 mb-md-0">
      Support Tool Box（サポ箱）
    </div>

    <!-- 中央：Facebook -->
    <div class="mb-2 mb-md-0">
      <a href="https://www.facebook.com" target="_blank" rel="noopener"
         class="text-white text-decoration-underline">
        Facebook ページ
      </a>
    </div>

    <!-- 右側：利用規約ボタン + コピーライト -->
    <div class="d-flex align-items-center">
      <button type="button"
              class="btn btn-outline-light btn-sm me-3"
              data-bs-toggle="modal"
              data-bs-target="#modalTerms">
        利用規約
      </button>
      <span class="navbar-text">
        © Support Tool Box（サポ箱）
      </span>
    </div>

  </div>
</footer>
`;
})();
