// top.js — TOPブロック（ロゴ＋サイト名＋ツール名／ロゴとサイト名にリンク付き）
(function () {
  var topEl = document.getElementById("top-block");
  if (!topEl) return;

  topEl.innerHTML = `
<header>
  <nav class="navbar navbar-expand-md navbar-dark bg-primary">
    <div class="container">

      <!-- ロゴ＋サイト名＋ツール名（ロゴとサイト名がindex.htmlへリンク） -->
      <a href="../../index.html" class="navbar-brand d-flex align-items-center me-3">

        <!-- SVGロゴ -->
        <span class="me-2">
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 64 64" role="img" aria-label="Support Tool Box ロゴ">
            <rect x="6" y="10" width="52" height="40" rx="8" ry="8" fill="#ffffff"></rect>
            <rect x="10" y="14" width="44" height="32" rx="6" ry="6" fill="#0d6efd"></rect>
            <text x="32" y="36" text-anchor="middle"
              font-family="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
              font-size="18" fill="#ffffff">
              STB
            </text>
          </svg>
        </span>

        <!-- サイト名 + ツール名 -->
        <span class="fw-bold">
          Support Tool Box（サポ箱）
          <span class="fw-normal ms-2">
            - T001 テンプレートツール名（ここを書き換えてください）
          </span>
        </span>

      </a>

      <!-- トグル（スマホ） -->
      <button class="navbar-toggler" type="button"
              data-bs-toggle="collapse"
              data-bs-target="#toolNavbar"
              aria-controls="toolNavbar"
              aria-expanded="false"
              aria-label="メニューを開く">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- ナビメニュー -->
      <div class="collapse navbar-collapse" id="toolNavbar">
        <ul class="navbar-nav ms-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#modalHowto">使い方</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#modalLinks">リンク</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#modalChangelog">更新履歴</a>
          </li>
        </ul>
      </div>

    </div>
  </nav>
</header>
`;
})();
